// cart.js

document.addEventListener("DOMContentLoaded", () => {
  const cartItemsContainer = document.getElementById("cart-items");
  const subtotalEl = document.getElementById("subtotal");
  const promoEl = document.getElementById("tax");
  const totalEl = document.getElementById("total");
  const checkoutBtn = document.querySelector("button.w-full");
  const changeBtn = document.querySelector("#change-address");
  const shippingText = document.querySelector("#shipping-text");

  let cart = JSON.parse(localStorage.getItem("cart")) || [];

  const formatCurrency = (num) => `$${num.toFixed(2)}`;
  const showToast = (message) => {
    const toast = document.createElement("div");
    toast.textContent = message;
    toast.className = "toast fixed bottom-4 right-4 bg-black text-white px-4 py-2 rounded-lg shadow-md z-50 text-sm";
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 2500);
  };

  const calculateSummary = () => {
    const selectedItems = cart.filter(item => item.selected);
    if (selectedItems.length === 0) {
      promoEl.parentElement.style.display = "none";
      totalEl.parentElement.style.display = "none";
      subtotalEl.textContent = "$0.00";
      cartItemsContainer.innerHTML = `
        <div class="bg-white p-4 rounded-lg text-center text-gray-500 border">
          You have to add items before check out products
        </div>`;
      return;
    }

    let subtotal = selectedItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
    let promoPercent = 0.05;
    try { promoPercent = 0.1; } catch { promoPercent = 0.05; }
    const promoAmount = subtotal * promoPercent;
    const total = subtotal - promoAmount;

    subtotalEl.textContent = formatCurrency(subtotal);
    promoEl.textContent = `- ${formatCurrency(promoAmount)}`;
    totalEl.textContent = formatCurrency(total);

    promoEl.parentElement.style.display = "flex";
    totalEl.parentElement.style.display = "flex";
  };

  const renderCart = () => {
    cartItemsContainer.innerHTML = "";
    if (cart.length === 0) return calculateSummary();

    cart.forEach((item, index) => {
      const itemEl = document.createElement("div");
      itemEl.className = "bg-white p-4 rounded-lg shadow-sm flex justify-between items-center";
      itemEl.innerHTML = `
        <div class="flex items-center gap-4">
          <input type="checkbox" ${item.selected ? "checked" : ""} onchange="toggleSelect(${index})">
          <img src="${item.image}" alt="${item.title}" class="w-20 h-20 object-cover rounded-md">
          <div>
            <h3 class="font-semibold">${item.title}</h3>
            <p class="text-gray-500 text-sm">${item.brand}</p>
            <p class="text-sm">Qty: ${item.quantity}</p>
            <p class="text-sm font-semibold">${formatCurrency(item.price * item.quantity)}</p>
          </div>
        </div>
        <div class="flex flex-col gap-2 text-sm items-end">
          <button class="hover:bg-gray-200 px-3 py-1 rounded border border-gray-400 transition" onclick="addToWishlist(${index})">❤️ Wishlist</button>
          <button class="hover:bg-red-100 text-red-600 px-3 py-1 rounded border border-gray-400 transition" onclick="removeItem(${index})">🗑️ Delete</button>
        </div>`;
      cartItemsContainer.appendChild(itemEl);
    });

    calculateSummary();
  };

  window.toggleSelect = (index) => {
    cart[index].selected = !cart[index].selected;
    localStorage.setItem("cart", JSON.stringify(cart));
    renderCart();
  };

  window.addToWishlist = (index) => {
    showToast("Added to wishlist!");
  };

  window.removeItem = (index) => {
    cart.splice(index, 1);
    localStorage.setItem("cart", JSON.stringify(cart));
    showToast("Item deleted");
    renderCart();
  };

  checkoutBtn.textContent = "Buy";
  checkoutBtn.addEventListener("click", () => {
    const selectedItems = cart.filter(item => item.selected);
    if (selectedItems.length === 0) {
      showToast("Your cart is empty!");
    } else {
      window.location.href = "checkout.html";
    }
  });

  const openChangeAddress = () => {
    const modal = document.createElement("div");
    modal.className = "fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-50";
    modal.innerHTML = `
      <div class="bg-white p-6 rounded-lg w-full max-w-md space-y-4">
        <h3 class="text-lg font-semibold">Change Shipping Address</h3>
        <textarea id="new-address" rows="3" class="w-full border p-2 rounded" placeholder="Enter new address...">${shippingText.innerText}</textarea>
        <div class="flex justify-between">
          <button id="use-location" class="text-blue-500 hover:underline">Use current location</button>
          <button id="save-address" class="bg-black text-white px-4 py-2 rounded hover:bg-gray-800">Save</button>
        </div>
      </div>`;
    document.body.appendChild(modal);

    document.getElementById("use-location").onclick = () => {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const coords = pos.coords;
          document.getElementById("new-address").value = `Lat: ${coords.latitude.toFixed(3)}, Long: ${coords.longitude.toFixed(3)}`;
        },
        () => alert("Failed to get location.")
      );
    };

    document.getElementById("save-address").onclick = () => {
      const newAddr = document.getElementById("new-address").value.trim();
      if (newAddr) {
        shippingText.innerHTML = `<p>${newAddr}</p><p class="text-gray-500">Updated</p>`;
        showToast("Address updated!");
        modal.remove();
      }
    };

    modal.addEventListener("click", (e) => {
      if (e.target === modal) modal.remove();
    });
  };

  changeBtn.addEventListener("click", openChangeAddress);
  renderCart();
});
