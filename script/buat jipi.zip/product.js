document.addEventListener("DOMContentLoaded", async () => {
  const id = new URLSearchParams(window.location.search).get("id");
  if (!id) {
    window.location.href = "product.html"; // Redirect without alert
    return;
  }

  try {
    const response = await fetch(`https://dummyjson.com/products/${id}`);
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    const product = await response.json();

    renderProduct(product);
    setupQuantityControls();
    setupCartButtons(product);
    setupWishlistButton(product);
    updateCartBadge();

  } catch (error) {
    console.error("Fetch failed:", error);
    // You could show a user-friendly error message in the UI here
  }
});

function renderProduct(product) {
  document.getElementById("product-title").textContent = product.title;
  document.getElementById("product-price").textContent = `$${product.price}`;
  document.getElementById("product-original").textContent = 
    `$${(product.price / (1 - product.discountPercentage/100)).toFixed(2)}`;
  document.getElementById("product-image").src = product.thumbnail;
  document.getElementById("product-brand").textContent = product.brand;
  document.getElementById("product-stock").textContent = `Stock: ${product.stock}`;
  document.getElementById("product-rating").textContent = product.rating;
  document.getElementById("product-description").textContent = product.description;
}

function setupQuantityControls() {
  const qtyInput = document.getElementById("qty-value");
  const qtyMinus = document.getElementById("qty-minus");
  const qtyPlus = document.getElementById("qty-plus");

  qtyMinus.addEventListener("click", () => {
    let current = parseInt(qtyInput.value);
    if (current > 1) qtyInput.value = current - 1;
  });

  qtyPlus.addEventListener("click", () => {
    let current = parseInt(qtyInput.value);
    qtyInput.value = current + 1;
  });
}

function setupCartButtons(product) {
  const qtyInput = document.getElementById("qty-value");
  const addToCartBtn = document.getElementById("add-to-cart");
  const buyNowBtn = document.querySelector("button.border.px-4");

  addToCartBtn.addEventListener("click", () => {
    const quantity = parseInt(qtyInput.value);
    updateCart(product, quantity);
    showFeedback("Added to cart!", "green");
  });

  buyNowBtn.addEventListener("click", () => {
    const quantity = parseInt(qtyInput.value);
    updateCart(product, quantity, true);
    window.location.href = "cart.html";
  });
}

function setupWishlistButton(product) {
  const wishlistBtn = document.querySelector("button.border.px-3");
  
  // Initialize button state
  updateWishlistButtonState(wishlistBtn, product.id);
  
  // Add click handler
  wishlistBtn.addEventListener("click", () => {
    const wishlist = JSON.parse(localStorage.getItem("wishlist")) || [];
    const existingIndex = wishlist.findIndex(item => item.id === product.id);
    
    if (existingIndex === -1) {
      wishlist.push({
        id: product.id,
        title: product.title,
        thumbnail: product.thumbnail,
        price: product.price
      });
      showFeedback("Added to wishlist!", "pink");
    } else {
      wishlist.splice(existingIndex, 1);
      showFeedback("Removed from wishlist!", "gray");
    }
    
    localStorage.setItem("wishlist", JSON.stringify(wishlist));
    updateWishlistButtonState(wishlistBtn, product.id);
  });
  
  // Add hover effects
  wishlistBtn.classList.add(
    'transition-colors',
    'duration-200',
    'hover:bg-gray-100',
    'active:bg-gray-200'
  );
}

function updateWishlistButtonState(button, productId) {
  const wishlist = JSON.parse(localStorage.getItem("wishlist")) || [];
  const isInWishlist = wishlist.some(item => item.id === productId);
  
  button.innerHTML = isInWishlist
    ? '<i class="fas fa-heart text-red-500 text-lg"></i>'
    : '<i class="far fa-heart text-lg"></i>';
}

function updateCart(product, quantity, isBuyNow = false) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];

  const itemToAdd = {
    id: product.id,
    image: product.thumbnail,
    title: product.title,
    brand: product.brand,
    price: product.price,
    quantity: quantity,
    selected: true
  };

  if (isBuyNow) {
    cart = [itemToAdd];
  } else {
    const existing = cart.find(item => item.id === product.id);
    if (existing) {
      existing.quantity += quantity;
    } else {
      cart.push(itemToAdd);
    }
  }

  localStorage.setItem("cart", JSON.stringify(cart));
  updateCartBadge();
}


function updateCartBadge() {
  const cart = JSON.parse(localStorage.getItem("cart")) || [];
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  document.getElementById("cart-count").textContent = totalItems;
}

function showFeedback(message, color) {
  const feedback = document.createElement("div");
  feedback.textContent = message;
  feedback.className = `fixed bottom-4 right-4 px-4 py-2 rounded-md bg-${color}-100 text-${color}-800 z-50`;
  document.body.appendChild(feedback);
  setTimeout(() => feedback.remove(), 2000);
}