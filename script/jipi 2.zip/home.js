document.addEventListener("DOMContentLoaded", () => {
  const allProductsContainer = document.getElementById("meet-selo");
  const houseContainer = document.getElementById("selo-house");
  const beautyContainer = document.getElementById("selo-beauty");
  const groceriesContainer = document.getElementById("selo-groceries");

  fetch("https://dummyjson.com/products")
    .then((res) => res.json())
    .then((data) => {
      const allProducts = data.products;

      allProducts.slice(5, 17).forEach((product) => {
        const card = createProductCard(product);
        allProductsContainer.appendChild(card); 
      });

      // house section (kategori rumah)
      allProducts
        .filter(product => ["furniture"].includes(product.category))
        .forEach(product => {
          const card = createProductCard(product);
          houseContainer.appendChild(card);
        });

      allProducts
        .filter(product => ["beauty", "fragrances"].includes(product.category))
        .forEach(product => {
          const card = createProductCard(product);
          beautyContainer.appendChild(card);
        });

      // groceries section (kategori teknologi)
      allProducts
        .filter(product => ["groceries"].includes(product.category))
        .forEach(product => {
          const card = createProductCard(product);
          groceriesContainer.appendChild(card);
        });

    })
    .catch((err) => {
      console.error("Gagal memuat data produk:", err);
      meetSeloContainer.innerHTML = clothingContainer.innerHTML = techContainer.innerHTML =
        "<p class='text-red-500 text-center'>Gagal memuat produk.</p>";
    });
});

  // Fungsi reusable untuk buat kartu produk
  function createProductCard(product) {
    const card = document.createElement("a");
    card.href = `product.html?id=${product.id}`;
    card.className =
      "block w-full bg-white hover:shadow-lg transition p-4";

    card.innerHTML = `
      <div class="aspect-square bg-gray-100 overflow-hidden mb-3">
        <img src="${product.thumbnail}" alt="${product.title}" class="w-full h-full object-cover">
      </div>
      <h3 class="text-sm font-semibold text-black" style="font-family: 'Inter', sans-serif;">${product.title}</h3>
      <p class="text-sm font-bold text-black mt-1" style="font-family: 'Inter', sans-serif;">$${product.price}</p>
    `;

    return card;
  }

// JavaScript for Slider
document.addEventListener("DOMContentLoaded", () => {
  const slider = document.getElementById("slider");
  const slides = slider.querySelectorAll("img");
  const dotsContainer = document.getElementById("dots");

  let currentIndex = 0;
  const totalSlides = slides.length;

  // Generate dots
  const dots = [];
  for (let i = 0; i < totalSlides; i++) {
    const dot = document.createElement("div");
    dot.className = "w-2 h-2 rounded-full bg-white/50 hover:bg-white cursor-pointer transition";
    dot.addEventListener("click", () => {
      currentIndex = i;
      updateSlider();
    });
    dotsContainer.appendChild(dot);
    dots.push(dot);
  }

  function updateSlider() {
    slider.style.transform = `translateX(-${currentIndex * 100}%)`;
    dots.forEach((dot, i) => {
      dot.classList.toggle("bg-white", i === currentIndex);
      dot.classList.toggle("bg-white/50", i !== currentIndex);
    });
  }

  // Auto slide
  setInterval(() => {
    currentIndex = (currentIndex + 1) % totalSlides;
    updateSlider();
  }, 4000);

  updateSlider(); // initial render
});
